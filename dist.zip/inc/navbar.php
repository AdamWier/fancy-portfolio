<div class="mx-auto">
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar"
            aria-label="Navbar Button">
            <span class="navbar-toggler-icon"><i class="fas fa-bars"></i></span>
          </button>
          <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav">
              <li class="nav-item"><a href="#about">Le créateur</a></li>
              <li class="nav-item"><a href="#certificates">Les brevets</a></li>
              <li class="nav-item"><a href="#projects">Les curiosités</a></li>
              <li class="nav-item"><a href="#contact">La correspondence</a></li>
            </ul>
          </div>
        </div>